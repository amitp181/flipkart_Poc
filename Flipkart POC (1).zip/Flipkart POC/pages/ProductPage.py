from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
import time
from pages.OrderPage import OrderPage


class ProductPage:
    add_to_cart = (By.XPATH, "//button[@class='_2KpZ6l _2U9uOA _3v1-ww']")

    def __init__(self, driver):
        self.driver = driver

    def add_item_to_cart(self):
        action = ActionChains(self.driver)
        action.scroll_by_amount(0, 1000).perform()
        time.sleep(1)
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located(
            *ProductPage.add_to_cart)).click()
        time.sleep(3)
        order_page = OrderPage(self.driver)
        return order_page

