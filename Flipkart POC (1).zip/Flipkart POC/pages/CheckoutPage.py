from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
import time


class CheckoutPage:
    email_textbox = (By.XPATH, "//input[@class='_2IX_2- _17N0em']")
    continue_button = (By.XPATH, "//button[@class='_2KpZ6l _20xBvF _3AWRsL']")
    error_text = (By.XPATH, "//span[@class='_2YULOR']/span")

    def __init__(self, driver):
        self.driver = driver

    def enter_email(self):
        email_input = self.driver.find_element(*CheckoutPage.email_textbox)
        email_input.send_keys("flipkart123")

    def click_continue(self):
        continue_button = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located(
            *CheckoutPage.continue_button))
        continue_button.click()

    def verify_valid_email(self):
        error_msg = self.driver.find_element(*CheckoutPage.error_text)
        if error_msg.text == "Please enter valid Email ID/Mobile number":
            print("Invalid Email ID/Mobile number")
        else:
            print("You have entered a valid Email ID/Mobile number")
