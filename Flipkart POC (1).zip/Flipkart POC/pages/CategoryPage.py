from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
from pages.ProductPage import ProductPage
import time


class CategoryPage:
    brand_button = (By.XPATH, "//div[contains(text(), 'Brand')]")
    brand_textbox = (By.XPATH, "//input[@class='_34uFYj']")
    check_box = (By.XPATH, "//div[@class='_24_Dny']")
    product_image = (By.XPATH, "//img[@class='_2r_T1I']")

    def __init__(self, driver):
        self.driver = driver

    # def click_brand(self):
    #     self.driver.find_element(*CategoryPage.brand_button).click()

    def select_brand(self):
        self.driver.execute_script("window.scrollBy(0,500)", "")
        time.sleep(2)
        brands = ['Fastrack', 'Wrogn', 'JSN']
        for item in brands:
            WebDriverWait(self.driver, 10).until(EC.presence_of_element_located(
                *CategoryPage.brand_button)).click()
            time.sleep(2)
            WebDriverWait(self.driver, 10).until(EC.presence_of_element_located(
                *CategoryPage.brand_textbox)).clear()
            WebDriverWait(self.driver, 10).until(EC.presence_of_element_located(
                *CategoryPage.brand_textbox)).send_keys(item)
            WebDriverWait(self.driver, 10).until(EC.presence_of_element_located(
                *CategoryPage.check_box)).click()
            time.sleep(2)

    def select_product(self):
        list_of_products = self.driver.find_elements(*CategoryPage.product_image)
        # Selects the third product in list
        list_of_products[2].click()
        time.sleep(5)

    def change_window(self):
        original_window = self.driver.current_window_handle
        for window_handle in self.driver.window_handles:
            if window_handle != original_window:
                self.driver.switch_to.window(window_handle)
                break
        product_page = ProductPage(self.driver)
        return product_page



