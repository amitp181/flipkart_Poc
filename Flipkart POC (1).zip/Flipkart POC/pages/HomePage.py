from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from pages.CategoryPage import CategoryPage
import time


class HomePage:
    cancel_button = (By.XPATH, "//*[@class='_2KpZ6l _2doB4z']")
    fashion_tab = (By.XPATH, "//*[text()='Fashion']")
    watch_acces = (By.XPATH, "//a[text()='Watches and Accessories']")
    wallets = (By.XPATH, "//a[text()='Wallets']")

    def __init__(self, driver):
        self.driver = driver

    def cancel_button(self):
        self.driver.find_element(*HomePage.cancel_button)

    def click_wallets(self):
        action = ActionChains(self.driver)
        action.move_to_element(self.driver.find_element(By.XPATH, "//*[text()='Fashion']")).perform()
        time.sleep(2)
        action.move_to_element(self.driver.find_element(By.XPATH, "//a[text()='Watches and Accessories']")).perform()
        time.sleep(2)
        action.move_to_element(self.driver.find_element(By.XPATH, "//a[text()='Wallets']")).click().perform()
        time.sleep(2)
        # action.move_to_element(self.driver.find_element(*HomePage.fashion_tab)).\
        #     move_to_element(self.driver.find_element(*HomePage.watch_acces))\
        #     .move_to_element(self.driver.find_element(*HomePage.wallets)).click().perform()
        category_page = CategoryPage(self.driver)
        return category_page



