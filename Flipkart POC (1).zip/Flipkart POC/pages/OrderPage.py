from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
import time

from pages.CheckoutPage import CheckoutPage


class OrderPage:
    increase_items = (By.XPATH, "//button[@class='_23FHuj' and text() = '+']")
    decrease_items = (By.XPATH, "//button[@class='_23FHuj' and text() = '–']")
    place_order_button = (By.XPATH, "//button[@class='_2KpZ6l _2ObVJD _3AWRsL']")

    def __init__(self, driver):
        self.driver = driver

    def increase_quantity(self):
        increase_button = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located(
            *OrderPage.increase_items))
        increase_button.click()
        time.sleep(2)

    def decrease_quantity(self):
        decrease_button = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located(
            *OrderPage.decrease_items))
        decrease_button.click()
        time.sleep(2)

    def place_order(self):
        place_order = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located(
            *OrderPage.place_order_button))
        time.sleep(5)
        place_order.click()
        time.sleep(2)
        checkout_page = CheckoutPage(self.driver)
        return checkout_page
