import time

from pages.HomePage import HomePage

class TestCase_01:
    def test_testcase_01(self):
        home_page = HomePage(self.driver)
        home_page.cancel_button()
        category_page = home_page.click_wallets()
        category_page.select_brand()
        category_page.select_product()
        product_page = category_page.change_window()
        order_page = product_page.add_item_to_cart()
        order_page.increase_items()
        order_page.decrease_items()
        checkout_page = order_page.place_order()
        checkout_page.enter_email()
        checkout_page.continue_button()
        checkout_page.verify_valid_email()
        time.sleep(4)



